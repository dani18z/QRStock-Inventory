import connexion
import six

from swagger_server.models.qr import Qr  # noqa: E501
from swagger_server import util


def generator_qr_get(name, size, color, stock):  # noqa: E501
    """generator_qr_get

    Generar código QR para un paquete # noqa: E501

    :param name: Nombre del producto
    :type name: dict | bytes
    :param size: Talla de la variante
    :type size: dict | bytes
    :param color: Color de la variante
    :type color: dict | bytes
    :param stock: Stock a introducir
    :type stock: dict | bytes

    :rtype: Qr
    """
    if connexion.request.is_json:
        name = Object.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        size = Object.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        color = Object.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        stock = Object.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def query_stock_get(name, size, color):  # noqa: E501
    """query_stock_get

    Consultar stock de una variante # noqa: E501

    :param name: Nombre del producto
    :type name: dict | bytes
    :param size: Talla de la variante
    :type size: dict | bytes
    :param color: Color de la variante
    :type color: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        name = Object.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        size = Object.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        color = Object.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def subtract_stock_post(body):  # noqa: E501
    """subtract_stock_post

    Actualización stock base de datos debido a paquete de salida (resta) # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Qr.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def subtract_stock_post(body):  # noqa: E501
    """subtract_stock_post

    Actualización stock base de datos debido a paquete de salida (resta) # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Qr.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def sum_stock_post(body):  # noqa: E501
    """sum_stock_post

    Actualización stock base de datos debido a paquete de entrada (suma) # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Qr.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def sum_stock_post(body):  # noqa: E501
    """sum_stock_post

    Actualización stock base de datos debido a paquete de entrada (suma) # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Qr.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
